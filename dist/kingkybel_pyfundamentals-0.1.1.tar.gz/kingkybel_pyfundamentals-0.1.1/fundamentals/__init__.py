__version__ = "0.1.0"

# Basic functions
from fundamentals.basic_functions import is_empty_string, now_string, now_string_short, now_date, now_year

# Exceptions
from fundamentals.exceptions import BaseScriptError, StringUtilError, ExtendedEnumError

# Extended enums
from fundamentals.extended_enum import ExtendedEnum, ExtendedFlag, EnumListType

# Overrides
from fundamentals.overrides import OverrideChecker, overrides

# Threading
from fundamentals.thread_with_return import ReturningThread

# Bash utilities
from fundamentals.bash import (
    get_effective_user, get_logged_in_user, assert_is_root, number_of_cores, 
    hostname, get_ip, get_external_ip, is_tool_installed, assert_tools_installed
)

# String utilities
from fundamentals.string_utils import (
    Encodings, IdentifierStringCase, FALSE_STRINGS, TRUE_STRINGS,
    input_value, squeeze_chars, remove_control_chars, matches_any,
    replace_all, normalise_sentence, get_random_string, contains_at_least_n_of,
    is_cpp_id, make_cpp_id, identify_case, split_text_into_chunks,
    is_utf8_ascii, is_roman_numeral, roman_to_integer
)
